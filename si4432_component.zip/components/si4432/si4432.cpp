
#include "si4432.h"

namespace esphome {
namespace si4432 {

// Lógica de implementación si es necesaria

}  // namespace si4432
}  // namespace esphome
